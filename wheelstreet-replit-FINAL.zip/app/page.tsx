import ClientPage from "./ClientPage"

export default function Home() {
  return <ClientPage />
}
